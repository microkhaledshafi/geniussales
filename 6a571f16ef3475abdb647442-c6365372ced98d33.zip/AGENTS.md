# AGENTS.md

This document serves as an architectural index and reference for AI agents or developers continuing work on this codebase.

## Application Architecture

The project has been modernized from an offline-only HTML application to a full-featured, database-backed ERP using Netlify Database and TanStack Start.

### Directory Structure

```
├── db/
│   ├── index.ts        # Database client using drizzle-orm/netlify-db adapter
│   └── schema.ts       # Database schemas for Customers, Stock, and Orders
├── netlify/
│   ├── database/
│   │   └── migrations/ # Automatically generated SQL migrations via drizzle-kit
│   └── functions/
│       └── api.mts     # Serverless controller function handling API paths
├── src/
│   ├── routes/
│   │   ├── __root.tsx  # Root page layout
│   │   └── index.tsx   # ERP Dashboard, Customers, Stock and Orders Live React UI
│   └── styles.css      # Tailwind utility styles
├── drizzle.config.ts   # Configuration for Drizzle Kit migration generation
└── netlify.toml        # Netlify project settings
```

## Database Schema & Migrations

All schema definitions live in `db/schema.ts`. When making modifications:
1. Update `db/schema.ts`
2. Run `npx drizzle-kit generate` to generate matching SQL migrations in `netlify/database/migrations/`
3. Netlify handles applying migrations to the environment (Preview / Production) automatically.
