import { pgTable, serial, text, integer, timestamp } from "drizzle-orm/pg-core";

export const customers = pgTable("customers", {
  id: serial().primaryKey(),
  name: text().notNull(),
  phone: text().notNull(),
  address: text().notNull().default(""),
  analyser: text().notNull().default(""),
  createdAt: timestamp("created_at").defaultNow(),
});

export const stock = pgTable("stock", {
  id: serial().primaryKey(),
  item: text().notNull(),
  qty: integer().notNull().default(0),
  lotNumber: text("lot_number").notNull().default(""),
  packSize: text("pack_size").notNull().default(""),
  expiryDate: text("expiry_date").notNull().default(""),
  hsnCode: text("hsn_code").notNull().default(""),
  taxRate: integer("tax_rate").notNull().default(0),
  createdAt: timestamp("created_at").defaultNow(),
});

export const orders = pgTable("orders", {
  id: serial().primaryKey(),
  customerId: integer("customer_id").notNull().references(() => customers.id, { onDelete: 'cascade' }),
  stockId: integer("stock_id").notNull().references(() => stock.id, { onDelete: 'cascade' }),
  qty: integer().notNull().default(1),
  status: text().notNull().default("Pending"), // "Pending" or "Served"
  createdAt: timestamp("created_at").defaultNow(),
});

export const leads = pgTable("leads", {
  id: serial().primaryKey(),
  name: text().notNull(),
  phone: text().notNull().default(""),
  email: text().notNull().default(""),
  source: text().notNull().default("Other"),
  interest: text().notNull().default(""),
  status: text().notNull().default("New"),
  notes: text().notNull().default(""),
  nextFollowUp: text("next_follow_up").notNull().default(""),
  createdAt: timestamp("created_at").defaultNow(),
});
