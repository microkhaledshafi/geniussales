# Genius Scientific ERP

A modern, cloud-native Enterprise Resource Planning (ERP) application for inventory, stock, customer, and order management. Completely redesigned from local-storage to use live database synchronization with Netlify Database (managed Postgres) and Drizzle ORM.

## Tech Stack

- **Framework:** TanStack Start (React 19)
- **Database:** Netlify Database (Postgres)
- **ORM:** Drizzle ORM (Beta release line)
- **Styling:** Tailwind CSS 4
- **Deploy Platform:** Netlify (with serverless functions serving `/api/*`)

## Getting Started

### Local Development

1. Run the local development server:
   ```bash
   npm run dev
   ```
2. Start the Netlify local emulator (includes local emulation of Netlify Database & Functions):
   ```bash
   netlify dev
   ```

### Deploying to Netlify

Migrations are automatically applied during production or deploy preview stages when deploying to Netlify. No manual action is needed.
