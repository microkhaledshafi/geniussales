CREATE TABLE "leads" (
  "id" serial PRIMARY KEY,
  "name" text NOT NULL,
  "phone" text DEFAULT '' NOT NULL,
  "email" text DEFAULT '' NOT NULL,
  "source" text DEFAULT 'Other' NOT NULL,
  "interest" text DEFAULT '' NOT NULL,
  "status" text DEFAULT 'New' NOT NULL,
  "notes" text DEFAULT '' NOT NULL,
  "next_follow_up" text DEFAULT '' NOT NULL,
  "created_at" timestamp DEFAULT now()
);
