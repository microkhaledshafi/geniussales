ALTER TABLE "stock" DROP CONSTRAINT IF EXISTS "stock_item_key";
--> statement-breakpoint
ALTER TABLE "stock" ADD COLUMN "lot_number" text DEFAULT '' NOT NULL;
--> statement-breakpoint
ALTER TABLE "stock" ADD COLUMN "pack_size" text DEFAULT '' NOT NULL;
--> statement-breakpoint
ALTER TABLE "stock" ADD COLUMN "expiry_date" text DEFAULT '' NOT NULL;
--> statement-breakpoint
ALTER TABLE "stock" ADD COLUMN "hsn_code" text DEFAULT '' NOT NULL;
--> statement-breakpoint
ALTER TABLE "stock" ADD COLUMN "tax_rate" integer DEFAULT 0 NOT NULL;
