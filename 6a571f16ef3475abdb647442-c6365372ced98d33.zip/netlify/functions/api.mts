import type { Config } from "@netlify/functions";
import { db } from "../../db/index.js";
import { customers, stock, orders, leads } from "../../db/schema.js";
import { eq, sql } from "drizzle-orm";

export default async (req: Request) => {
  const url = new URL(req.url);
  const path = url.pathname;
  const method = req.method;

  try {
    // -------------------------------------------------------------
    // 0. LEADS ENDPOINTS
    // -------------------------------------------------------------
    if (path.startsWith("/api/leads")) {
      const match = path.match(/\/api\/leads\/(\d+)/);
      const id = match ? parseInt(match[1]) : null;

      if (method === "GET") {
        return Response.json(await db.select().from(leads).orderBy(leads.createdAt));
      }
      if (method === "POST") {
        const body = await req.json();
        if (!body.name) return Response.json({ error: "Lead name is required" }, { status: 400 });
        const [lead] = await db.insert(leads).values({
          name: body.name, phone: body.phone || "", email: body.email || "",
          source: body.source || "Other", interest: body.interest || "",
          status: body.status || "New", notes: body.notes || "", nextFollowUp: body.nextFollowUp || "",
        }).returning();
        return Response.json(lead, { status: 201 });
      }
      if (method === "PUT" && id) {
        const body = await req.json();
        const [lead] = await db.update(leads).set({
          name: body.name, phone: body.phone || "", email: body.email || "",
          source: body.source || "Other", interest: body.interest || "",
          status: body.status || "New", notes: body.notes || "", nextFollowUp: body.nextFollowUp || "",
        }).where(eq(leads.id, id)).returning();
        return Response.json(lead);
      }
      if (method === "DELETE" && id) {
        await db.delete(leads).where(eq(leads.id, id));
        return Response.json({ success: true });
      }
    }

    // -------------------------------------------------------------
    // 1. CUSTOMERS ENDPOINTS
    // -------------------------------------------------------------
    if (path.startsWith("/api/customers")) {
      const match = path.match(/\/api\/customers\/(\d+)/);
      const id = match ? parseInt(match[1]) : null;

      if (method === "GET") {
        const list = await db.select().from(customers).orderBy(customers.name);
        return Response.json(list);
      }

      if (method === "POST") {
        const body = await req.json();
        if (!body.name || !body.phone) {
          return Response.json({ error: "Name and Phone are required" }, { status: 400 });
        }
        const [newCust] = await db.insert(customers).values({
          name: body.name,
          phone: body.phone,
          address: body.address || "",
          analyser: body.analyser || "",
        }).returning();
        return Response.json(newCust, { status: 201 });
      }

      if (method === "PUT" && id) {
        const body = await req.json();
        const [updated] = await db.update(customers).set({
          name: body.name,
          phone: body.phone,
          address: body.address,
          analyser: body.analyser,
        }).where(eq(customers.id, id)).returning();
        return Response.json(updated);
      }

      if (method === "DELETE" && id) {
        await db.delete(customers).where(eq(customers.id, id));
        return Response.json({ success: true });
      }
    }

    // -------------------------------------------------------------
    // 2. STOCK ENDPOINTS
    // -------------------------------------------------------------
    if (path.startsWith("/api/stock")) {
      const match = path.match(/\/api\/stock\/(\d+)/);
      const id = match ? parseInt(match[1]) : null;

      if (method === "GET") {
        const list = await db.select().from(stock).orderBy(stock.item);
        return Response.json(list);
      }

      if (method === "POST") {
        const body = await req.json();
        if (!body.item) {
          return Response.json({ error: "Item name is required" }, { status: 400 });
        }
        const [newStock] = await db.insert(stock).values({
          item: body.item,
          qty: body.qty || 0,
          lotNumber: body.lotNumber || "",
          packSize: body.packSize || "",
          expiryDate: body.expiryDate || "",
          hsnCode: body.hsnCode || "",
          taxRate: Number.isInteger(Number(body.taxRate)) ? Number(body.taxRate) : 0,
        }).returning();
        return Response.json(newStock, { status: 201 });
      }

      if (method === "PUT" && id) {
        const body = await req.json();
        const [updated] = await db.update(stock).set({
          qty: body.qty,
        }).where(eq(stock.id, id)).returning();
        return Response.json(updated);
      }

      if (method === "DELETE" && id) {
        await db.delete(stock).where(eq(stock.id, id));
        return Response.json({ success: true });
      }
    }

    // -------------------------------------------------------------
    // 3. ORDERS ENDPOINTS
    // -------------------------------------------------------------
    if (path.startsWith("/api/orders")) {
      const match = path.match(/\/api\/orders\/(\d+)/);
      const id = match ? parseInt(match[1]) : null;

      if (method === "GET") {
        // We can do a join to return detailed order information
        const list = await db.select({
          id: orders.id,
          customerId: orders.customerId,
          customerName: customers.name,
          stockId: orders.stockId,
          item: stock.item,
          lotNumber: stock.lotNumber,
          packSize: stock.packSize,
          expiryDate: stock.expiryDate,
          hsnCode: stock.hsnCode,
          taxRate: stock.taxRate,
          qty: orders.qty,
          status: orders.status,
          createdAt: orders.createdAt,
        }).from(orders)
          .innerJoin(customers, eq(orders.customerId, customers.id))
          .innerJoin(stock, eq(orders.stockId, stock.id))
          .orderBy(orders.createdAt);
        return Response.json(list);
      }

      if (method === "POST") {
        const body = await req.json();
        if (!body.customerId || !body.stockId) {
          return Response.json({ error: "Customer and Stock Item are required" }, { status: 400 });
        }
        const [newOrder] = await db.insert(orders).values({
          customerId: parseInt(body.customerId),
          stockId: parseInt(body.stockId),
          qty: parseInt(body.qty) || 1,
          status: "Pending",
        }).returning();
        return Response.json(newOrder, { status: 201 });
      }

      if (method === "PUT" && id) {
        const body = await req.json();
        if (body.action === "serve") {
          // Find the order
          const [order] = await db.select().from(orders).where(eq(orders.id, id)).limit(1);
          if (!order) return Response.json({ error: "Order not found" }, { status: 404 });
          if (order.status === "Served") return Response.json({ error: "Order already served" }, { status: 400 });

          // Find the stock
          const [st] = await db.select().from(stock).where(eq(stock.id, order.stockId)).limit(1);
          if (!st) return Response.json({ error: "Item not found in stock" }, { status: 404 });
          if (st.qty < order.qty) return Response.json({ error: "Not enough stock!" }, { status: 400 });

          // Deduct stock and update order status (ideally in a transaction)
          await db.update(stock).set({ qty: st.qty - order.qty }).where(eq(stock.id, st.id));
          const [updatedOrder] = await db.update(orders).set({ status: "Served" }).where(eq(orders.id, id)).returning();
          return Response.json(updatedOrder);
        }
      }

      if (method === "DELETE" && id) {
        await db.delete(orders).where(eq(orders.id, id));
        return Response.json({ success: true });
      }
    }

    // -------------------------------------------------------------
    // 4. RESET ENDPOINT
    // -------------------------------------------------------------
    if (path === "/api/reset" && method === "POST") {
      await db.delete(orders);
      await db.delete(leads);
      await db.delete(customers);
      await db.delete(stock);
      return Response.json({ success: true });
    }

    return new Response("Not Found", { status: 404 });
  } catch (error: any) {
    console.error("API error:", error);
    return Response.json({ error: error.message || "Internal Server Error" }, { status: 500 });
  }
};

export const config: Config = {
  path: [
    "/api/customers",
    "/api/customers/:id",
    "/api/stock",
    "/api/stock/:id",
    "/api/orders",
    "/api/orders/:id",
    "/api/reset",
    "/api/leads",
    "/api/leads/:id"
  ],
};
